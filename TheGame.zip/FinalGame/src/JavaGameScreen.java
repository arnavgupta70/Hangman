/******************************************************************************
* File Name:	FinalGame_Hangman
* Programmer:	Arnav Gupta
* Date:		March 22, 2020
* Description:	This program is designed to simulate the game of Hangman. It 
*               will include the user having to guess the names of the 30 teams 
*               in the NBA (National Basketball Association). The user will 
*               guess from the 26 letters in the alphabet. If the letter guessed
*               by the user is in the name, its position will be revealed. The 
*               user can only have a maximum of 6 incorrect guesses. After that,
*               the game will be over and the user will have the option to 
*               either Play Again or Exit.
*******************************************************************************/

// Imports the libraries required for the execution of the code.
import java.util.Random;
import javax.swing.ImageIcon;

import java.io.*;                   // Imports input output libraries
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.swing.JOptionPane;
import javax.xml.parsers.*;         // Imports the library to be able to read (parse) XML files

import javax.xml.transform.*;       // Library used to transform source to result
import javax.xml.transform.dom.DOMSource; 
import javax.xml.transform.stream.StreamResult;

import org.w3c.dom.*;               // Allows for XML processing
import org.xml.sax.*;               // Assists in XML processing

// "JavaGameScreen" class with "javax.swing.JFrame" extension
public class JavaGameScreen extends javax.swing.JFrame {

    /* Creates a String Array called "teams" which consists of the NBA teams 
    the user has to guess. The team, PHILADELPHIA 76ERS is not included due to 
    the numeric values. */
    String [] teams = {"RAPTORS", "LAKERS", "WARRIORS", "TIMBERWOLVES", 
        "MAVERICKS", "HAWKS", "HEAT", "SUNS", "KINGS", "PACERS", "CELTICS", 
        "ROCKETS", "CLIPPERS", "BUCKS", "BULLS", "PELICANS", "SPURS", "KNICKS", 
        "CAVALIERS", "JAZZ", "THUNDER", "NETS", "TRAILBLAZERS", "NUGGETS", 
        "GRIZZLIES", "HORNETS", "MAGIC", "WIZARDS", "PISTONS"};
    
    // Creates a new Random variable, called "random". 
    Random random = new Random();
    
    /* Creates an Integer variable, called "index", which will be used to store 
    a randomly generated Index Position from the "teams" array. */
    int index = random.nextInt(teams.length);
    
    /* Creates a String variable, "teamName" which stores the name of the team, 
    from the String Array "teams" at the Index Position ("index", generated 
    above). This name is the word the user has to guess in order to win. */
    String teamName = teams[index];
    
    /* Defines a new Integer variable, "letterInWord" and sets the value to 0. 
    This is the variable which will be used to determine if the game has ended. */
    int letterInWord = 0;
        
    /* Defines a new Integer variable, "correctGuesses" and sets the value to 0.
    This is the variable which will be incremented by 1 everytime the user 
    guesses a letter in the team name. */
    int correctGuesses = 0;
    
    /* Defines a new Integer variable, "incorrectGuesses" and sets the value to 
    0. In this game, there is a maximum of 6 incorrect guesses, after which the 
    game the ends. So, this is the variable which will be incremented by 1 
    everytime the user guesses a letter not in the team name. */
    int incorrectGuesses = 0;

    /* Creates a String variable, "underlineName" which will be used to store 
    the team name as blanks, displayed in the "labelUnderlineName" JLabel on the 
    Game Screen. */
    String underlineName = "";
    
    /* Creates an Integer variable, "gamesPlayed" and sets the value to 0. This 
    variable will be used to keep track of the number of games the user has 
    played. */
    int gameNumber = 0;
    
    /* Creates an Integer variable, "gamesWon" and sets the value to 0. This 
    variable will be used to keep track of the number of wins (words the user 
    has guessed correctly). */
    int gamesWon = 0;
   
    /* Creates an Integer variable, "gamesLost" and sets the value to 0. This 
    variable will be used to keep track of the number of losses (words the user 
    was UNABLE to guess correctly). */
    int gamesLost = 0;

    // Creates the Output Window
    public JavaGameScreen() {
        
        /* The JFrame has been centered on the Screen by clicking the 
        "Generate Center" under the Properties Section of the JFrame. */
        initComponents();
        
        /* This command sets all the buttons to enabled, to allow the user to 
        choose the letters they represent. This is because, during the first 
        run, as the user guesses the leters, they become invisible. However, 
        should the user decide to Play Again by clicking "Yes" on the Result 
        Screen, the buttons must once again be enabled. */
        btnA.setEnabled(true);
        btnB.setEnabled(true);
        btnC.setEnabled(true);
        btnD.setEnabled(true);
        btnE.setEnabled(true);
        btnF.setEnabled(true);
        btnG.setEnabled(true);
        btnH.setEnabled(true);
        btnI.setEnabled(true);
        btnJ.setEnabled(true);
        btnK.setEnabled(true);
        btnL.setEnabled(true);
        btnM.setEnabled(true);
        btnN.setEnabled(true);
        btnO.setEnabled(true);
        btnP.setEnabled(true);
        btnQ.setEnabled(true);
        btnR.setEnabled(true);
        btnS.setEnabled(true);
        btnT.setEnabled(true);
        btnU.setEnabled(true);
        btnV.setEnabled(true);
        btnW.setEnabled(true);
        btnX.setEnabled(true);
        btnY.setEnabled(true);
        btnZ.setEnabled(true);
        btnHint.setEnabled(true);

        /* Creates a for loop to access each letter within the team name 
        randomly selected, which is stored in the String variable, "teamName". */
        for (int i = 0; i < teamName.length(); i++) {
            
            /* Creates a new String variable, "blanks* which adds a blank to 
            the String variable, "underlineName". */
            String blanks = "_ ";
            underlineName = blanks + underlineName;
        }
        
        // Defines 3 new String variables "x,y,z" which are blank. 
        String x = "";
        String y = "";
        String z = "";
        
        // This trys to catch any exceptions in the code
        try {
            
            // Brings the "Score.xml" XML file into the program
            String filepath = "Score.xml";
            DocumentBuilderFactory docFactory = DocumentBuilderFactory.newInstance();
            DocumentBuilder docBuilder = docFactory.newDocumentBuilder();
            Document doc = docBuilder.parse(filepath); 
            
            // Gets the first category ("Played") element by tag name directly.
            Node completed = doc.getElementsByTagName("Played").item(0);
            
            /* Sets value of String variable, "x" to the Node Value of 
            "completed" */
            x = completed.getFirstChild().getNodeValue();
            
            // Gets the first category ("Won") element by tag name directly.
            Node wins = doc.getElementsByTagName("Won").item(0);
            
            /* Sets value of String variable, "y" to the Node Value of 
            "wins" */
            y = wins.getFirstChild().getNodeValue();
            
            // Gets the first category ("Lost") element by tag name directly.
            Node losses = doc.getElementsByTagName("Lost").item(0);
            
            /* Sets value of String variable, "z" to the Node Value of 
            "losses" */
            z = losses.getFirstChild().getNodeValue();
        }
            
        // Tries to catch any exceptions
        catch (ParserConfigurationException | SAXException | IOException ex) {
            Logger.getLogger(JavaGameScreen.class.getName()).log(Level.SEVERE, null, ex);
        }
        
        /* Sets the value of Integer variable, "gamesPlayed" to the value stored
        in the String variable, "x". However, the String variable, "x" must be 
        parsed (convert from String to Integer). */
        gameNumber = Integer.parseInt(x);
        
        /* Sets the value of Integer variable, "gamesWon" to the value stored
        in the String variable, "y". However, the String variable, "y" must be 
        parsed (convert from String to Integer). */
        gamesWon = Integer.parseInt(y);
        
        /* Sets the value of Integer variable, "gamesLost" to the value stored
        in the String variable, "z". However, the String variable, "z" must be 
        parsed (convert from String to Integer). */
        gamesLost = Integer.parseInt(z);

        /* This command increments the Integer variable, "gamesPlayed" by 1 
        everytime the For Loop above is executed. This is because, when the 
        above code is run, a new team name is randomly selected from the String 
        Array "teams" indicating the start of a new game. */
        gameNumber += 1;
        
        // Loads the image which highlights the frame of the Hangman Game
        ImageIcon frame = new ImageIcon("1.jpg");
                
        /* Sets the image, stored in "frame" as the Icon for the 
        "labelHangmanImage" JLabel. */
        labelHangmanImage.setIcon(frame);
        
        /* These commands change the text in the 3 labels on the game screen to 
        inform the user about the number of games played/won/lost. */
        labelGamesPlayed.setText("Game Number: " + gameNumber);
        labelWins.setText("Games Won: " + gamesWon);
        labelLosses.setText("Games Lost: " + gamesLost);

        /* Sets the text of the "labelUnderlineName" to the String variable, 
        "underlineName" to provide the user with a hint as to how many letters 
        there are in the team name. */
        labelUnderlineName.setText(underlineName);
    }
    
    /* Creates a method, "userLetterSelection" which takes a CHAR parameter. 
    This command takes a CHAR parameter because to check if the letter guessed 
    by the user is included within the team name, access for the letters is 
    required. However, the "teamName[i]" command will not work because 
    "teamName" is a String variable and not an array.
    
    This method is called within the code of all the Letter buttons. It then 
    checks if the letter clicked by the user is included within the name. By 
    creating this method, it increases efficiency because otherwise this piece 
    of code would have been called within the code of each letter. */
    public int userLetterSelection(char a) {
        
        /* This command resets the value of the Integer variable, "letterInWord"
        to ZERO to ensure that it is ready the next time the user clicks a 
        letter. */
        letterInWord = 0;
        
        // This command increments the Integer variable, "incorrectGuesses" by 1
        incorrectGuesses += 1;
        
        /* 
        Title: <JavaScript String charAt() Method>
        Author: <w3>
        Access Date: <March 21, 2020>
        Code Version: <JAVA>
        Availability: <https://www.w3schools.com/jsref/jsref_charat.asp>
        
        Creates a For Loop, which will be used to access each letter in the 
        randomly selected team name, stored in the String variable, "teamName". */
        for (int i = 0; i < teamName.length(); i++) {
            
            /* The ".charAt()" is a method which returns a CHAR value from the 
            specified index position "i". A CHAR value is a data type that holds
            ONE character, or in this instance, a letter from the String 
            variable, "teamName". This command checks to see if the "letter" 
            which the FOR LOOP is currently on is equal to the "letter" chosen 
            by the user. */
            if ((teamName.charAt(i)) == (a)) {
                
                /* This command replaces the blanks at the Index Position "i" 
                in the String variable, "underlineName" to the letter guessed by
                the user. Through this, all of the other positions will also be 
                revealed because there are many instances where the team name 
                has the same letter multiple times. */
                underlineName = underlineName.substring(0, (i*2)) + a + underlineName.substring((i*2) + 1);
                
                /* Increments the Integer variable, "letterInWord" by 1*/
                letterInWord = 1;
                               
                // Increments the Integer variable, "correctGuesses" by 1
                correctGuesses += 1;
            }
        }
        
        /* This If Statement is only accessed when the value stored in the 
        Integer variable, "letterInWord" is 1. The only way for the value to be 
        changed to ONE is if the letter guessed by the user is in the word. */
        if (letterInWord == 1) {
            
            /* The user wins if they guess all the letters in the word. Since 
            the variable, "correctGuesses" is incremented by 1 each time the 
            user guesses a letter included in the word, for the user to win, the
            value stored in the Integer variable, "correctGuesses" must be equal
            to the number of letters in the randomly selected team name. 
        
            For example, if the team name was "RAPTORS", for the user to win, 
            the value stored in the "correctGuesses" variable must be 7.*/
            if (correctGuesses == teamName.length()) {
            
                /* This command increments the Integer variable, "gamesWon" by a 
                value of 1, indicating that the user has successfully guessed 
                the team name.*/
                gamesWon += 1;
                
                try {
                    // Calls the method, "scoreToXML" defined below
                    scoreToXML(gameNumber, gamesWon, gamesLost);
                } 
                catch (SAXException | IOException ex) {
                    Logger.getLogger(JavaGameScreen.class.getName()).log(Level.SEVERE, null, ex);
                }

                /* After the user has won the game, this command closes the 
                current, "JavaGameScreen" JFrame. */
                this.setVisible(false);
            
                /* An Overload Constructor has been defined the "JavaWin" 
                JFrame. So, this command calls that method to display the Win 
                Screen. On this screen, the user is reminded of the team name 
                they had to guess, and is given the option to play the game 
                again, should they choose to do so. */
                new JavaWin(teamName).setVisible(true);
            }
            
            /* Since the letter guessed by the user is included in the team 
            name, this is not an incorrect guess. Therefore, this command 
            subtracts 1 from the value stored in the Integer variable, 
            "incorrectGuesses". */
            incorrectGuesses -= 1;
        }

        /* This "ELSE" statement is accessed if the value stored in the Integer 
        variable, "letterInWord" is not 1. */
        else {
            
            /* This command checks if the value stored in the Integer variable, 
            "incorrectGuesses" is equal to 1. */
            if (incorrectGuesses == 1) {
                
                // Loads the image which highlights the head of the Hangman
                ImageIcon head = new ImageIcon("2.jpg");
                
                /* Sets the image, stored in "head" as the Icon for the 
                "labelHangmanImage" JLabel. */
                labelHangmanImage.setIcon(head);
            }
            
            /* This command checks if the value stored in the Integer variable, 
            "incorrectGuesses" is equal to 2. */
            if (incorrectGuesses == 2) {
                
                // Loads the image which highlights the body of the Hangman
                ImageIcon body = new ImageIcon("3.jpg");
                
                /* Sets the image, stored in "body" as the Icon for the 
                "labelHangmanImage" JLabel. */
                labelHangmanImage.setIcon(body);
            }
            
            /* This command checks if the value stored in the Integer variable, 
            "incorrectGuesses" is equal to 3. */
            if (incorrectGuesses == 3) {
                
                // Loads the image which highlights the left leg of the Hangman
                ImageIcon leg1 = new ImageIcon("4.jpg");
                
                /* Sets the image, stored in "leg1" as the Icon for the 
                "labelHangmanImage" JLabel. */
                labelHangmanImage.setIcon(leg1);
            }
            
            /* This command checks if the value stored in the Integer variable, 
            "incorrectGuesses" is equal to 4. */
            if (incorrectGuesses == 4) {
                
                // Loads the image which highlights the right leg of the Hangman
                ImageIcon leg2 = new ImageIcon("5.jpg");
                
                /* Sets the image, stored in "leg2" as the Icon for the 
                "labelHangmanImage" JLabel. */
                labelHangmanImage.setIcon(leg2);
            }
            
            /* This command checks if the value stored in the Integer variable, 
            "incorrectGuesses" is equal to 5. */
            if (incorrectGuesses == 5) {
                
                // Loads the image which highlights the right arm of the Hangman
                ImageIcon arm1 = new ImageIcon("6.jpg");
                
                /* Sets the image, stored in "arm1" as the Icon for the 
                "labelHangmanImage" JLabel. */
                labelHangmanImage.setIcon(arm1);
            }
            
            /* This command checks if the value stored in the Integer variable, 
            "incorrectGuesses" is equal to 6. */
            if (incorrectGuesses == 6) {
                
                // Loads the image which highlights the left arm of the Hangman
                ImageIcon arm2 = new ImageIcon("7.jpg");
                
                /* Sets the image, stored in "arm2" as the Icon for the 
                "labelHangmanImage" JLabel. */
                labelHangmanImage.setIcon(arm2);
                
                /* This command increments the Integer variable, "gamesLost" by 
                a value of 1, indicating that the user was unable to guess the 
                team name.*/
                gamesLost += 1;
                
                try {
                    // Calls the method, "scoreToXML" defined below
                    scoreToXML(gameNumber, gamesWon, gamesLost);
                } 
                catch (SAXException | IOException ex) {
                    Logger.getLogger(JavaGameScreen.class.getName()).log(Level.SEVERE, null, ex);
                }

                /* After the user has lost the game, this command closes the 
                current,"JavaGameScreen" JFrame. */
                this.setVisible(false);
                
                /* An Overload Constructor has been defined the "JavaLoss" 
                JFrame. So, this command calls that method to display the Loss 
                Screen. On this screen, the user is informed of the team name 
                they had to guess, and is given the option to play the game 
                again, should they choose to do so. */
                new JavaLoss(teamName).setVisible(true);
            }
        }
        
        /* Sets the text of the "labelUnderlineName" to the String variable, 
        "underlineName" which has been updated to display the letter(s) guessed 
        by the user, if it is included in the name. */
        labelUnderlineName.setText(underlineName); 
        
        /* This command returns a random number (0) as it is required due to 
        this method requiring a value within it's parameters. */
        return 0;
    }
    
    /* Defines a new method, "scoreToXML" which takes 3 parameters, which are 
    all Integers. This method is primarily used to update the score in the XML 
    file. Due to my game having each screen on a seperate JFrame, this XML file 
    will also be used to keep track of games played/won/lost in between games. 
    This method will convert all the 3 parameters, "a,b,c" from Integer to 
    String because only a String value can be appended into the XML file. */
    public void scoreToXML(int a, int b, int c) throws SAXException, IOException {
        
        // This trys to catch any exceptions in the code
        try {  
            
            // Brings the "Score.xml" XML file into the program
            String filepath = "Score.xml";
            DocumentBuilderFactory docFactory = DocumentBuilderFactory.newInstance();
            DocumentBuilder docBuilder = docFactory.newDocumentBuilder();
            Document doc = docBuilder.parse(filepath); 
            
            /* Converts the 3 parameters "a,b,c" from Integers to Strings and 
            stores them in 3 different variables "x,y,z". */
            String x = Integer.toString(a);
            String y = Integer.toString(b);
            String z = Integer.toString(c);
            
            // Get the first category ("Played") element by tag name directly.
            Node games_played = doc.getElementsByTagName("Played").item(0);
            
            /* Change the value to the updated value, which was incremented by 
            1 at the start of the new game. */
            games_played.setTextContent(x);
            
            // Get the second category ("Won") element by tag name directly.
            Node games_won = doc.getElementsByTagName("Won").item(0);
            
            /* Change the value to the updated value, which was possibly 
            incremented by 1, if the user succesfully guessed the team name. */
            games_won.setTextContent(y);
            
            // Get the third category ("Lost") element by tag name directly.
            Node games_lost = doc.getElementsByTagName("Lost").item(0);
            
            /* Change the value to the updated value, which was possibly 
            incremented by 1, if the user was unable to guess the team name. */
            games_lost.setTextContent(z);
            
            // write the content into xml file
            TransformerFactory transformerFactory = TransformerFactory.newInstance();
            Transformer transformer = transformerFactory.newTransformer();
            
            // makes sure the XML file is formatted nicely with indentation
            transformer.setOutputProperty(OutputKeys.INDENT, "yes");   
            
            //makes sure the XML file is formatted nicely with indent space of 4 
            transformer.setOutputProperty("{http://xml.apache.org/xslt}indent-amount", "4");  
            DOMSource source = new DOMSource(doc);
            StreamResult result = new StreamResult(new File(filepath));
            transformer.transform(source, result);
        }
        
        // Tries to catch any exceptions
        catch (ParserConfigurationException | TransformerException | IOException | SAXException pce) { 
            pce.printStackTrace();
	}
    }
    
    /* Defines a new method, "clearXML()", which will be used to clear the XML 
    file should the user choose to do so.*/
    public void clearXML() {
        
        // This trys to catch any exceptions in the code
        try {  
            
            // This allows for the creation of the XML file
            DocumentBuilderFactory docFactory = DocumentBuilderFactory.newInstance();   
            
            // Enables information to read from XML file 
            DocumentBuilder docBuilder = docFactory.newDocumentBuilder();  
            
            // Root elements
            Document doc = docBuilder.newDocument();
            
            // Calls the root element in the XML "Inventory"
            Element rootElement = doc.createElement("HangmanScore");  
            doc.appendChild(rootElement);
            
            // Score elements
            Element games = doc.createElement("Games");
            rootElement.appendChild(games);
            
            // Number of games played element and appends a String value of "0".          
            Element played = doc.createElement("Played");
            played.appendChild(doc.createTextNode("0"));
            games.appendChild(played);
            
            // Number of games won element and appends a String value of "0".
            Element won = doc.createElement("Won");
            won.appendChild(doc.createTextNode("0"));
            games.appendChild(won);
            
            // Number of games lost element and appends a String value of "0".
            Element lost = doc.createElement("Lost");
            lost.appendChild(doc.createTextNode("0"));
            games.appendChild(lost);
            
            // write the content into XML file
            TransformerFactory transformerFactory = TransformerFactory.newInstance();
            Transformer transformer = transformerFactory.newTransformer();
            DOMSource source = new DOMSource(doc);

            // Makes sure the XML file is formatted nicely with indentation
            transformer.setOutputProperty(OutputKeys.INDENT, "yes");   

            // Makes sure the XML file is formatted nicely with indent space of 4 
            transformer.setOutputProperty("{http://xml.apache.org/xslt}indent-amount", "4");  

            // creates the file called "Score"
            StreamResult result = new StreamResult(new File("Score.xml"));  

            // Output to console screen  for testing, but you need to comment-out the previous "StreamResult result" line above. 
            //StreamResult result = new StreamResult(System.out);
            transformer.transform(source, result); 
        }
        
        // Tries to catch any exceptions
        catch (ParserConfigurationException | TransformerException pce) { 
            pce.printStackTrace();
	} 
    }

    /**
     * This method is called from within the constructor to initialize the form.
     * WARNING: Do NOT modify this code. The content of this method is always
     * regenerated by the Form Editor.
     */
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        panelButtons = new javax.swing.JPanel();
        btnA = new javax.swing.JButton();
        btnB = new javax.swing.JButton();
        btnC = new javax.swing.JButton();
        btnD = new javax.swing.JButton();
        btnE = new javax.swing.JButton();
        btnF = new javax.swing.JButton();
        btnG = new javax.swing.JButton();
        btnH = new javax.swing.JButton();
        btnI = new javax.swing.JButton();
        btnJ = new javax.swing.JButton();
        btnK = new javax.swing.JButton();
        btnL = new javax.swing.JButton();
        btnM = new javax.swing.JButton();
        btnN = new javax.swing.JButton();
        btnO = new javax.swing.JButton();
        btnP = new javax.swing.JButton();
        btnQ = new javax.swing.JButton();
        btnR = new javax.swing.JButton();
        btnS = new javax.swing.JButton();
        btnT = new javax.swing.JButton();
        btnU = new javax.swing.JButton();
        btnV = new javax.swing.JButton();
        btnW = new javax.swing.JButton();
        btnX = new javax.swing.JButton();
        btnY = new javax.swing.JButton();
        btnZ = new javax.swing.JButton();
        labelUnderlineName = new javax.swing.JLabel();
        btnHint = new javax.swing.JButton();
        labelHint = new javax.swing.JLabel();
        labelHead = new javax.swing.JLabel();
        labelHangmanImage = new javax.swing.JLabel();
        btnResetScore = new javax.swing.JButton();
        labelWins = new javax.swing.JLabel();
        labelLosses = new javax.swing.JLabel();
        labelGamesPlayed = new javax.swing.JLabel();
        jLabel1 = new javax.swing.JLabel();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        setTitle("NBA Teams Hangman Game Screen");
        setBackground(new java.awt.Color(255, 255, 255));
        setPreferredSize(new java.awt.Dimension(1066, 800));

        btnA.setBackground(new java.awt.Color(51, 153, 255));
        btnA.setFont(new java.awt.Font("Tahoma", 1, 24)); // NOI18N
        btnA.setText("A");
        btnA.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnAActionPerformed(evt);
            }
        });

        btnB.setBackground(new java.awt.Color(51, 153, 255));
        btnB.setFont(new java.awt.Font("Tahoma", 1, 24)); // NOI18N
        btnB.setText("B");
        btnB.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnBActionPerformed(evt);
            }
        });

        btnC.setBackground(new java.awt.Color(51, 153, 255));
        btnC.setFont(new java.awt.Font("Tahoma", 1, 24)); // NOI18N
        btnC.setText("C");
        btnC.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnCActionPerformed(evt);
            }
        });

        btnD.setBackground(new java.awt.Color(51, 153, 255));
        btnD.setFont(new java.awt.Font("Tahoma", 1, 24)); // NOI18N
        btnD.setText("D");
        btnD.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnDActionPerformed(evt);
            }
        });

        btnE.setBackground(new java.awt.Color(51, 153, 255));
        btnE.setFont(new java.awt.Font("Tahoma", 1, 24)); // NOI18N
        btnE.setText("E");
        btnE.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnEActionPerformed(evt);
            }
        });

        btnF.setBackground(new java.awt.Color(51, 153, 255));
        btnF.setFont(new java.awt.Font("Tahoma", 1, 24)); // NOI18N
        btnF.setText("F");
        btnF.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnFActionPerformed(evt);
            }
        });

        btnG.setBackground(new java.awt.Color(51, 153, 255));
        btnG.setFont(new java.awt.Font("Tahoma", 1, 24)); // NOI18N
        btnG.setText("G");
        btnG.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnGActionPerformed(evt);
            }
        });

        btnH.setBackground(new java.awt.Color(51, 153, 255));
        btnH.setFont(new java.awt.Font("Tahoma", 1, 24)); // NOI18N
        btnH.setText("H");
        btnH.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnHActionPerformed(evt);
            }
        });

        btnI.setBackground(new java.awt.Color(51, 153, 255));
        btnI.setFont(new java.awt.Font("Tahoma", 1, 24)); // NOI18N
        btnI.setText("I");
        btnI.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnIActionPerformed(evt);
            }
        });

        btnJ.setBackground(new java.awt.Color(51, 153, 255));
        btnJ.setFont(new java.awt.Font("Tahoma", 1, 24)); // NOI18N
        btnJ.setText("J");
        btnJ.setToolTipText("");
        btnJ.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnJActionPerformed(evt);
            }
        });

        btnK.setBackground(new java.awt.Color(51, 153, 255));
        btnK.setFont(new java.awt.Font("Tahoma", 1, 24)); // NOI18N
        btnK.setText("K");
        btnK.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnKActionPerformed(evt);
            }
        });

        btnL.setBackground(new java.awt.Color(51, 153, 255));
        btnL.setFont(new java.awt.Font("Tahoma", 1, 24)); // NOI18N
        btnL.setText("L");
        btnL.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnLActionPerformed(evt);
            }
        });

        btnM.setBackground(new java.awt.Color(51, 153, 255));
        btnM.setFont(new java.awt.Font("Tahoma", 1, 24)); // NOI18N
        btnM.setText("M");
        btnM.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnMActionPerformed(evt);
            }
        });

        btnN.setBackground(new java.awt.Color(51, 153, 255));
        btnN.setFont(new java.awt.Font("Tahoma", 1, 24)); // NOI18N
        btnN.setText("N");
        btnN.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnNActionPerformed(evt);
            }
        });

        btnO.setBackground(new java.awt.Color(51, 153, 255));
        btnO.setFont(new java.awt.Font("Tahoma", 1, 24)); // NOI18N
        btnO.setText("O");
        btnO.setToolTipText("");
        btnO.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnOActionPerformed(evt);
            }
        });

        btnP.setBackground(new java.awt.Color(51, 153, 255));
        btnP.setFont(new java.awt.Font("Tahoma", 1, 24)); // NOI18N
        btnP.setText("P");
        btnP.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnPActionPerformed(evt);
            }
        });

        btnQ.setBackground(new java.awt.Color(51, 153, 255));
        btnQ.setFont(new java.awt.Font("Tahoma", 1, 24)); // NOI18N
        btnQ.setText("Q");
        btnQ.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnQActionPerformed(evt);
            }
        });

        btnR.setBackground(new java.awt.Color(51, 153, 255));
        btnR.setFont(new java.awt.Font("Tahoma", 1, 24)); // NOI18N
        btnR.setText("R");
        btnR.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnRActionPerformed(evt);
            }
        });

        btnS.setBackground(new java.awt.Color(51, 153, 255));
        btnS.setFont(new java.awt.Font("Tahoma", 1, 24)); // NOI18N
        btnS.setText("S");
        btnS.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnSActionPerformed(evt);
            }
        });

        btnT.setBackground(new java.awt.Color(51, 153, 255));
        btnT.setFont(new java.awt.Font("Tahoma", 1, 24)); // NOI18N
        btnT.setText("T");
        btnT.setToolTipText("");
        btnT.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnTActionPerformed(evt);
            }
        });

        btnU.setBackground(new java.awt.Color(51, 153, 255));
        btnU.setFont(new java.awt.Font("Tahoma", 1, 24)); // NOI18N
        btnU.setText("U");
        btnU.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnUActionPerformed(evt);
            }
        });

        btnV.setBackground(new java.awt.Color(51, 153, 255));
        btnV.setFont(new java.awt.Font("Tahoma", 1, 24)); // NOI18N
        btnV.setText("V");
        btnV.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnVActionPerformed(evt);
            }
        });

        btnW.setBackground(new java.awt.Color(51, 153, 255));
        btnW.setFont(new java.awt.Font("Tahoma", 1, 24)); // NOI18N
        btnW.setText("W");
        btnW.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnWActionPerformed(evt);
            }
        });

        btnX.setBackground(new java.awt.Color(51, 153, 255));
        btnX.setFont(new java.awt.Font("Tahoma", 1, 24)); // NOI18N
        btnX.setText("X");
        btnX.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnXActionPerformed(evt);
            }
        });

        btnY.setBackground(new java.awt.Color(51, 153, 255));
        btnY.setFont(new java.awt.Font("Tahoma", 1, 24)); // NOI18N
        btnY.setText("Y");
        btnY.setToolTipText("");
        btnY.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnYActionPerformed(evt);
            }
        });

        btnZ.setBackground(new java.awt.Color(51, 153, 255));
        btnZ.setFont(new java.awt.Font("Tahoma", 1, 24)); // NOI18N
        btnZ.setText("Z");
        btnZ.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnZActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout panelButtonsLayout = new javax.swing.GroupLayout(panelButtons);
        panelButtons.setLayout(panelButtonsLayout);
        panelButtonsLayout.setHorizontalGroup(
            panelButtonsLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(panelButtonsLayout.createSequentialGroup()
                .addGap(20, 20, 20)
                .addGroup(panelButtonsLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(panelButtonsLayout.createSequentialGroup()
                        .addComponent(btnP, javax.swing.GroupLayout.PREFERRED_SIZE, 60, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(15, 15, 15)
                        .addComponent(btnQ, javax.swing.GroupLayout.PREFERRED_SIZE, 60, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(15, 15, 15)
                        .addComponent(btnR, javax.swing.GroupLayout.PREFERRED_SIZE, 60, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(15, 15, 15)
                        .addComponent(btnS, javax.swing.GroupLayout.PREFERRED_SIZE, 60, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(15, 15, 15)
                        .addComponent(btnT, javax.swing.GroupLayout.PREFERRED_SIZE, 60, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGroup(panelButtonsLayout.createSequentialGroup()
                        .addComponent(btnK, javax.swing.GroupLayout.PREFERRED_SIZE, 60, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(15, 15, 15)
                        .addComponent(btnL, javax.swing.GroupLayout.PREFERRED_SIZE, 60, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(15, 15, 15)
                        .addComponent(btnM, javax.swing.GroupLayout.PREFERRED_SIZE, 60, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(15, 15, 15)
                        .addComponent(btnN, javax.swing.GroupLayout.PREFERRED_SIZE, 60, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(15, 15, 15)
                        .addComponent(btnO, javax.swing.GroupLayout.PREFERRED_SIZE, 60, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGroup(panelButtonsLayout.createSequentialGroup()
                        .addComponent(btnF, javax.swing.GroupLayout.PREFERRED_SIZE, 60, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(15, 15, 15)
                        .addComponent(btnG, javax.swing.GroupLayout.PREFERRED_SIZE, 60, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(15, 15, 15)
                        .addComponent(btnH, javax.swing.GroupLayout.PREFERRED_SIZE, 60, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(15, 15, 15)
                        .addComponent(btnI, javax.swing.GroupLayout.PREFERRED_SIZE, 60, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(15, 15, 15)
                        .addComponent(btnJ, javax.swing.GroupLayout.PREFERRED_SIZE, 60, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGroup(panelButtonsLayout.createSequentialGroup()
                        .addComponent(btnA, javax.swing.GroupLayout.PREFERRED_SIZE, 60, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(15, 15, 15)
                        .addComponent(btnB, javax.swing.GroupLayout.PREFERRED_SIZE, 60, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(15, 15, 15)
                        .addComponent(btnC, javax.swing.GroupLayout.PREFERRED_SIZE, 60, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(15, 15, 15)
                        .addComponent(btnD, javax.swing.GroupLayout.PREFERRED_SIZE, 60, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(15, 15, 15)
                        .addComponent(btnE, javax.swing.GroupLayout.PREFERRED_SIZE, 60, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGroup(panelButtonsLayout.createSequentialGroup()
                        .addComponent(btnU, javax.swing.GroupLayout.PREFERRED_SIZE, 60, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(15, 15, 15)
                        .addComponent(btnV, javax.swing.GroupLayout.PREFERRED_SIZE, 60, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(15, 15, 15)
                        .addGroup(panelButtonsLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(btnZ, javax.swing.GroupLayout.PREFERRED_SIZE, 60, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addGroup(panelButtonsLayout.createSequentialGroup()
                                .addComponent(btnW, javax.swing.GroupLayout.PREFERRED_SIZE, 60, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addGap(15, 15, 15)
                                .addComponent(btnX, javax.swing.GroupLayout.PREFERRED_SIZE, 60, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addGap(15, 15, 15)
                                .addComponent(btnY, javax.swing.GroupLayout.PREFERRED_SIZE, 60, javax.swing.GroupLayout.PREFERRED_SIZE)))))
                .addGap(20, 20, 20))
        );
        panelButtonsLayout.setVerticalGroup(
            panelButtonsLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(panelButtonsLayout.createSequentialGroup()
                .addGap(20, 20, 20)
                .addGroup(panelButtonsLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(btnA, javax.swing.GroupLayout.PREFERRED_SIZE, 50, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(btnB, javax.swing.GroupLayout.PREFERRED_SIZE, 50, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(btnC, javax.swing.GroupLayout.PREFERRED_SIZE, 50, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(btnD, javax.swing.GroupLayout.PREFERRED_SIZE, 50, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(btnE, javax.swing.GroupLayout.PREFERRED_SIZE, 50, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(20, 20, 20)
                .addGroup(panelButtonsLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(btnF, javax.swing.GroupLayout.PREFERRED_SIZE, 50, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(btnG, javax.swing.GroupLayout.PREFERRED_SIZE, 50, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(btnH, javax.swing.GroupLayout.PREFERRED_SIZE, 50, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(btnI, javax.swing.GroupLayout.PREFERRED_SIZE, 50, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(btnJ, javax.swing.GroupLayout.PREFERRED_SIZE, 50, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(20, 20, 20)
                .addGroup(panelButtonsLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(btnK, javax.swing.GroupLayout.PREFERRED_SIZE, 50, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(btnL, javax.swing.GroupLayout.PREFERRED_SIZE, 50, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(btnM, javax.swing.GroupLayout.PREFERRED_SIZE, 50, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(btnN, javax.swing.GroupLayout.PREFERRED_SIZE, 50, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(btnO, javax.swing.GroupLayout.PREFERRED_SIZE, 50, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(20, 20, 20)
                .addGroup(panelButtonsLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(btnP, javax.swing.GroupLayout.PREFERRED_SIZE, 50, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(btnQ, javax.swing.GroupLayout.PREFERRED_SIZE, 50, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(btnR, javax.swing.GroupLayout.PREFERRED_SIZE, 50, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(btnS, javax.swing.GroupLayout.PREFERRED_SIZE, 50, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(btnT, javax.swing.GroupLayout.PREFERRED_SIZE, 50, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(20, 20, 20)
                .addGroup(panelButtonsLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(btnU, javax.swing.GroupLayout.PREFERRED_SIZE, 50, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(btnV, javax.swing.GroupLayout.PREFERRED_SIZE, 50, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(btnW, javax.swing.GroupLayout.PREFERRED_SIZE, 50, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(btnX, javax.swing.GroupLayout.PREFERRED_SIZE, 50, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(btnY, javax.swing.GroupLayout.PREFERRED_SIZE, 50, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(20, 20, 20)
                .addComponent(btnZ, javax.swing.GroupLayout.PREFERRED_SIZE, 50, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(20, 20, 20))
        );

        labelUnderlineName.setFont(new java.awt.Font("Tahoma", 1, 30)); // NOI18N
        labelUnderlineName.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);

        btnHint.setBackground(new java.awt.Color(255, 204, 0));
        btnHint.setFont(new java.awt.Font("Verdana", 1, 24)); // NOI18N
        btnHint.setText("Hint");
        btnHint.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnHintActionPerformed(evt);
            }
        });

        labelHint.setFont(new java.awt.Font("Tahoma", 1, 16)); // NOI18N
        labelHint.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);

        labelHead.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);

        labelHangmanImage.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);

        btnResetScore.setFont(new java.awt.Font("Tahoma", 1, 18)); // NOI18N
        btnResetScore.setText("Clear Score");
        btnResetScore.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnResetScoreActionPerformed(evt);
            }
        });

        labelWins.setBackground(new java.awt.Color(51, 204, 0));
        labelWins.setFont(new java.awt.Font("Verdana", 1, 14)); // NOI18N
        labelWins.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        labelWins.setBorder(new javax.swing.border.LineBorder(new java.awt.Color(0, 0, 0), 1, true));

        labelLosses.setBackground(new java.awt.Color(204, 0, 0));
        labelLosses.setFont(new java.awt.Font("Verdana", 1, 14)); // NOI18N
        labelLosses.setForeground(new java.awt.Color(0, 153, 0));
        labelLosses.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        labelLosses.setBorder(new javax.swing.border.LineBorder(new java.awt.Color(0, 0, 0), 1, true));

        labelGamesPlayed.setBackground(new java.awt.Color(51, 204, 0));
        labelGamesPlayed.setFont(new java.awt.Font("Verdana", 1, 14)); // NOI18N
        labelGamesPlayed.setForeground(new java.awt.Color(255, 102, 0));
        labelGamesPlayed.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        labelGamesPlayed.setBorder(new javax.swing.border.LineBorder(new java.awt.Color(0, 0, 0), 1, true));

        jLabel1.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Game Screen Image.jpg"))); // NOI18N

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                    .addGroup(javax.swing.GroupLayout.Alignment.LEADING, layout.createSequentialGroup()
                        .addGap(53, 53, 53)
                        .addComponent(labelHint, javax.swing.GroupLayout.PREFERRED_SIZE, 960, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGroup(layout.createSequentialGroup()
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(layout.createSequentialGroup()
                                .addGap(343, 343, 343)
                                .addComponent(labelHead)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, layout.createSequentialGroup()
                                .addContainerGap(89, Short.MAX_VALUE)
                                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, layout.createSequentialGroup()
                                        .addComponent(btnHint, javax.swing.GroupLayout.PREFERRED_SIZE, 200, javax.swing.GroupLayout.PREFERRED_SIZE)
                                        .addGap(208, 208, 208))
                                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, layout.createSequentialGroup()
                                        .addComponent(labelHangmanImage, javax.swing.GroupLayout.PREFERRED_SIZE, 400, javax.swing.GroupLayout.PREFERRED_SIZE)
                                        .addGap(95, 95, 95))
                                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, layout.createSequentialGroup()
                                        .addComponent(jLabel1)
                                        .addGap(67, 67, 67)))))
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                            .addComponent(panelButtons, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                            .addComponent(labelUnderlineName, javax.swing.GroupLayout.PREFERRED_SIZE, 400, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(labelGamesPlayed, javax.swing.GroupLayout.PREFERRED_SIZE, 150, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addGroup(layout.createSequentialGroup()
                                .addComponent(labelWins, javax.swing.GroupLayout.PREFERRED_SIZE, 150, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addGap(79, 79, 79)
                                .addComponent(btnResetScore, javax.swing.GroupLayout.PREFERRED_SIZE, 136, javax.swing.GroupLayout.PREFERRED_SIZE))
                            .addComponent(labelLosses, javax.swing.GroupLayout.PREFERRED_SIZE, 150, javax.swing.GroupLayout.PREFERRED_SIZE))))
                .addGap(50, 50, 50))
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, layout.createSequentialGroup()
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(layout.createSequentialGroup()
                        .addGap(15, 15, 15)
                        .addComponent(labelGamesPlayed, javax.swing.GroupLayout.PREFERRED_SIZE, 35, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(15, 15, 15)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(labelWins, javax.swing.GroupLayout.PREFERRED_SIZE, 35, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(btnResetScore, javax.swing.GroupLayout.PREFERRED_SIZE, 40, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addGap(15, 15, 15)
                        .addComponent(labelLosses, javax.swing.GroupLayout.PREFERRED_SIZE, 35, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(15, 15, 15)
                        .addComponent(labelUnderlineName, javax.swing.GroupLayout.PREFERRED_SIZE, 50, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(20, 20, 20)
                        .addComponent(panelButtons, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGroup(layout.createSequentialGroup()
                        .addGap(23, 23, 23)
                        .addComponent(jLabel1, javax.swing.GroupLayout.PREFERRED_SIZE, 208, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(11, 11, 11)
                        .addComponent(labelHead)
                        .addGap(18, 18, 18)
                        .addComponent(labelHangmanImage, javax.swing.GroupLayout.PREFERRED_SIZE, 302, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                        .addComponent(btnHint, javax.swing.GroupLayout.PREFERRED_SIZE, 90, javax.swing.GroupLayout.PREFERRED_SIZE)))
                .addGap(40, 40, 40)
                .addComponent(labelHint, javax.swing.GroupLayout.PREFERRED_SIZE, 50, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(40, 40, 40))
        );

        pack();
        setLocationRelativeTo(null);
    }// </editor-fold>//GEN-END:initComponents

    // Code for A Button - Executed when user clicks "A".
    private void btnAActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnAActionPerformed
        
        /* This command calls the "userLetterSelection" method defined above 
        with "A" in its parameter. */
        userLetterSelection('A');
        
        /* After the user has clicked this button, this command disables it 
        because the user cannot guess this letter again. */
        btnA.setEnabled(false);
    }//GEN-LAST:event_btnAActionPerformed

    // Code for B Button - Executed when user clicks "B".
    private void btnBActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnBActionPerformed

        /* This command calls the "userLetterSelection" method defined above 
        with "B" in its parameter. */
        userLetterSelection('B');

        /* After the user has clicked this button, this command disables it 
        because the user cannot guess this letter again. */
        btnB.setEnabled(false);
    }//GEN-LAST:event_btnBActionPerformed

    // Code for C Button - Executed when user clicks "C".
    private void btnCActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnCActionPerformed
        
        /* This command calls the "userLetterSelection" method defined above 
        with "C" in its parameter. */
        userLetterSelection('C');

        /* After the user has clicked this button, this command disables it 
        because the user cannot guess this letter again. */
        btnC.setEnabled(false);
    }//GEN-LAST:event_btnCActionPerformed

    // Code for D Button - Executed when user clicks "D".
    private void btnDActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnDActionPerformed
        
        /* This command calls the "userLetterSelection" method defined above 
        with "D" in its parameter. */
        userLetterSelection('D');

        /* After the user has clicked this button, this command disables it 
        because the user cannot guess this letter again. */
        btnD.setEnabled(false);
    }//GEN-LAST:event_btnDActionPerformed

    // Code for E Button - Executed when user clicks "E".
    private void btnEActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnEActionPerformed
          
        /* This command calls the "userLetterSelection" method defined above 
        with "E" in its parameter. */
        userLetterSelection('E');

        /* After the user has clicked this button, this command disables it 
        because the user cannot guess this letter again. */
        btnE.setEnabled(false);
    }//GEN-LAST:event_btnEActionPerformed

    // Code for F Button - Executed when user clicks "F".
    private void btnFActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnFActionPerformed
        
        /* This command calls the "userLetterSelection" method defined above 
        with "F" in its parameter. */
        userLetterSelection('F');

        /* After the user has clicked this button, this command disables it 
        because the user cannot guess this letter again. */
        btnF.setEnabled(false);    
    }//GEN-LAST:event_btnFActionPerformed

    // Code for G Button - Executed when user clicks "G".
    private void btnGActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnGActionPerformed
        
        /* This command calls the "userLetterSelection" method defined above 
        with "G" in its parameter. */
        userLetterSelection('G');

        /* After the user has clicked this button, this command disables it 
        because the user cannot guess this letter again. */
        btnG.setEnabled(false);
    }//GEN-LAST:event_btnGActionPerformed

    // Code for H Button - Executed when user clicks "H".
    private void btnHActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnHActionPerformed
       
        /* This command calls the "userLetterSelection" method defined above 
        with "H" in its parameter. */
        userLetterSelection('H');

        /* After the user has clicked this button, this command disables it 
        because the user cannot guess this letter again. */
        btnH.setEnabled(false);
    }//GEN-LAST:event_btnHActionPerformed

    // Code for I Button - Executed when user clicks "I".
    private void btnIActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnIActionPerformed
        
        /* This command calls the "userLetterSelection" method defined above 
        with "I" in its parameter. */
        userLetterSelection('I');

        /* After the user has clicked this button, this command disables it 
        because the user cannot guess this letter again. */
        btnI.setEnabled(false);
    }//GEN-LAST:event_btnIActionPerformed

    // Code for J Button - Executed when user clicks "J".
    private void btnJActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnJActionPerformed
               
        /* This command calls the "userLetterSelection" method defined above 
        with "J" in its parameter. */
        userLetterSelection('J');

        /* After the user has clicked this button, this command disables it 
        because the user cannot guess this letter again. */
        btnJ.setEnabled(false);
    }//GEN-LAST:event_btnJActionPerformed

    // Code for K Button - Executed when user clicks "K".
    private void btnKActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnKActionPerformed
       
        /* This command calls the "userLetterSelection" method defined above 
        with "K" in its parameter. */
        userLetterSelection('K');

        /* After the user has clicked this button, this command disables it 
        because the user cannot guess this letter again. */
        btnK.setEnabled(false);
    }//GEN-LAST:event_btnKActionPerformed

    // Code for L Button - Executed when user clicks "L".
    private void btnLActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnLActionPerformed
       
        /* This command calls the "userLetterSelection" method defined above 
        with "L" in its parameter. */
        userLetterSelection('L');

        /* After the user has clicked this button, this command disables it 
        because the user cannot guess this letter again. */
        btnL.setEnabled(false);
    }//GEN-LAST:event_btnLActionPerformed

    // Code for M Button - Executed when user clicks "M".
    private void btnMActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnMActionPerformed
        
        /* This command calls the "userLetterSelection" method defined above 
        with "M" in its parameter. */
        userLetterSelection('M');

        /* After the user has clicked this button, this command disables it 
        because the user cannot guess this letter again. */
        btnM.setEnabled(false);
    }//GEN-LAST:event_btnMActionPerformed

    // Code for N Button - Executed when user clicks "N".
    private void btnNActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnNActionPerformed
        
        /* This command calls the "userLetterSelection" method defined above 
        with "N" in its parameter. */
        userLetterSelection('N');

        /* After the user has clicked this button, this command disables it 
        because the user cannot guess this letter again. */
        btnN.setEnabled(false);
    }//GEN-LAST:event_btnNActionPerformed

    // Code for O Button - Executed when user clicks "O".
    private void btnOActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnOActionPerformed
        
        /* This command calls the "userLetterSelection" method defined above 
        with "O" in its parameter. */
        userLetterSelection('O');

        /* After the user has clicked this button, this command disables it 
        because the user cannot guess this letter again. */
        btnO.setEnabled(false);
    }//GEN-LAST:event_btnOActionPerformed

    // Code for P Button - Executed when user clicks "P".
    private void btnPActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnPActionPerformed
        
        /* This command calls the "userLetterSelection" method defined above 
        with "P" in its parameter. */
        userLetterSelection('P');

        /* After the user has clicked this button, this command disables it 
        because the user cannot guess this letter again. */
        btnP.setEnabled(false);
    }//GEN-LAST:event_btnPActionPerformed

    // Code for Q Button - Executed when user clicks "Q".
    private void btnQActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnQActionPerformed
        
        /* This command calls the "userLetterSelection" method defined above 
        with "Q" in its parameter. */
        userLetterSelection('Q');

        /* After the user has clicked this button, this command disables it 
        because the user cannot guess this letter again. */
        btnQ.setEnabled(false);
    }//GEN-LAST:event_btnQActionPerformed

    // Code for R Button - Executed when user clicks "R".
    private void btnRActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnRActionPerformed
        
        /* This command calls the "userLetterSelection" method defined above 
        with "R" in its parameter. */
        userLetterSelection('R');

        /* After the user has clicked this button, this command disables it 
        because the user cannot guess this letter again. */
        btnR.setEnabled(false);
    }//GEN-LAST:event_btnRActionPerformed

    // Code for S Button - Executed when user clicks "S".
    private void btnSActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnSActionPerformed
        
        /* This command calls the "userLetterSelection" method defined above 
        with "S" in its parameter. */
        userLetterSelection('S');

        /* After the user has clicked this button, this command disables it 
        because the user cannot guess this letter again. */
        btnS.setEnabled(false);
    }//GEN-LAST:event_btnSActionPerformed

    // Code for T Button - Executed when user clicks "T".
    private void btnTActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnTActionPerformed
             
        /* This command calls the "userLetterSelection" method defined above 
        with "T" in its parameter. */
        userLetterSelection('T');

        /* After the user has clicked this button, this command disables it 
        because the user cannot guess this letter again. */
        btnT.setEnabled(false);
    }//GEN-LAST:event_btnTActionPerformed

    // Code for U Button - Executed when user clicks "U".
    private void btnUActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnUActionPerformed
               
        /* This command calls the "userLetterSelection" method defined above 
        with "U" in its parameter. */
        userLetterSelection('U');

        /* After the user has clicked this button, this command disables it 
        because the user cannot guess this letter again. */
        btnU.setEnabled(false);
    }//GEN-LAST:event_btnUActionPerformed

    // Code for V Button - Executed when user clicks "V".
    private void btnVActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnVActionPerformed
                
        /* This command calls the "userLetterSelection" method defined above 
        with "V" in its parameter. */
        userLetterSelection('V');

        /* After the user has clicked this button, this command disables it 
        because the user cannot guess this letter again. */
        btnV.setEnabled(false);
    }//GEN-LAST:event_btnVActionPerformed

    // Code for W Button - Executed when user clicks "W".
    private void btnWActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnWActionPerformed
                
        /* This command calls the "userLetterSelection" method defined above 
        with "W" in its parameter. */
        userLetterSelection('W');

        /* After the user has clicked this button, this command disables it 
        because the user cannot guess this letter again. */
        btnW.setEnabled(false); 
    }//GEN-LAST:event_btnWActionPerformed

    // Code for X Button - Executed when user clicks "X".
    private void btnXActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnXActionPerformed
                
        /* This command calls the "userLetterSelection" method defined above 
        with "X" in its parameter. */
        userLetterSelection('X');

        /* After the user has clicked this button, this command disables it 
        because the user cannot guess this letter again. */
        btnX.setEnabled(false);
    }//GEN-LAST:event_btnXActionPerformed

    // Code for Y Button - Executed when user clicks "Y".
    private void btnYActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnYActionPerformed
        
        /* This command calls the "userLetterSelection" method defined above 
        with "Y" in its parameter. */
        userLetterSelection('Y');

        /* After the user has clicked this button, this command disables it 
        because the user cannot guess this letter again. */
        btnY.setEnabled(false);
    }//GEN-LAST:event_btnYActionPerformed

    // Code for Z Button - Executed when user clicks "Z".
    private void btnZActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnZActionPerformed
        
        /* This command calls the "userLetterSelection" method defined above 
        with "Z" in its parameter. */
        userLetterSelection('Z');

        /* After the user has clicked this button, this command disables it 
        because the user cannot guess this letter again. */
        btnZ.setEnabled(false);
    }//GEN-LAST:event_btnZActionPerformed

    // Code for Changing Team Button - Executed when user clicks "Change Team".
    private void btnHintActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnHintActionPerformed
        
        /* This command checks if the randomly generated team name from the 
        String Array "teams" is "RAPTORS". */
        if (teamName.equals("RAPTORS")) {
            
            /* Changes the text of the Hint Label to some piece of information 
            related to the "RAPTORS" to aid the user in guessing the team. */
            labelHint.setText("This team is the only NBA team not based in USA.");
        }
        
/*************Only to indicate separation between hints of 2 teams*************/
        
        /* This command checks if the randomly generated team name from the 
        String Array "teams" is "LAKERS". */
        if (teamName.equals("LAKERS")) {
            
            /* Changes the text of the Hint Label to some piece of information 
            related to the "LAKERS" to aid the user in guessing the team. */
            labelHint.setText("The late, Kobe Bryant played for this team for 20 seasons.");
        }
        
/*************Only to indicate separation between hints of 2 teams*************/
        
        /* This command checks if the randomly generated team name from the 
        String Array "teams" is "WARRIORS". */
        if (teamName.equals("WARRIORS")) {
            
            /* Changes the text of the Hint Label to some piece of information 
            related to the "WARRIORS" to aid the user in guessing the team. */
            labelHint.setText("This team holds the NBA record for the most wins (73) in a regular season.");
        }
        
/*************Only to indicate separation between hints of 2 teams*************/
        
        /* This command checks if the randomly generated team name from the 
        String Array "teams" is "TIMBERWOLVES". */
        if (teamName.equals("TIMBERWOLVES")) {
            
            /* Changes the text of the Hint Label to some piece of information 
            related to the "TIMBERWOLVES" to aid the user in guessing the team. */
            labelHint.setText("This team is based in Minneapolis, Minnesota, USA.");
        }
        
/*************Only to indicate separation between hints of 2 teams*************/
        
        /* This command checks if the randomly generated team name from the 
        String Array "teams" is "MAVERICKS". */
        if (teamName.equals("MAVERICKS")) {
            
            /* Changes the text of the Hint Label to some piece of information 
            related to the "MAVERICKS" to aid the user in guessing the team. */
            labelHint.setText("Dirk Nowitzki played for this team for 20 seasons.");
        }
        
/*************Only to indicate separation between hints of 2 teams*************/
        
        /* This command checks if the randomly generated team name from the 
        String Array "teams" is "HAWKS". */
        if (teamName.equals("HAWKS")) {
            
            /* Changes the text of the Hint Label to some piece of information 
            related to the "HAWKS" to aid the user in guessing the team. */
            labelHint.setText("This team is based in Atlanta, Georgia, USA.");
        }
        
/*************Only to indicate separation between hints of 2 teams*************/
        
        /* This command checks if the randomly generated team name from the 
        String Array "teams" is "HEAT". */
        if (teamName.equals("HEAT")) {
            
            /* Changes the text of the Hint Label to some piece of information 
            related to the "HEAT" to aid the user in guessing the team. */
            labelHint.setText("This team won the NBA Championship for 2 consecutive years in 2012, 2013 led by LeBron James and Dwayne Wade.");
        }
        
/*************Only to indicate separation between hints of 2 teams*************/
        
        /* This command checks if the randomly generated team name from the 
        String Array "teams" is "SUNS". */
        if (teamName.equals("SUNS")) {
            
            /* Changes the text of the Hint Label to some piece of information 
            related to the "SUNS" to aid the user in guessing the team. */
            labelHint.setText("This team is based in Phoenix, Arizona, USA.");
        }
        
/*************Only to indicate separation between hints of 2 teams*************/
        
        /* This command checks if the randomly generated team name from the 
        String Array "teams" is "KINGS". */
        if (teamName.equals("KINGS")) {
            
            /* Changes the text of the Hint Label to some piece of information 
            related to the "KINGS" to aid the user in guessing the team. */
            labelHint.setText("This team is based in Sacramento, California, USA.");
        }
        
/*************Only to indicate separation between hints of 2 teams*************/
        
        /* This command checks if the randomly generated team name from the 
        String Array "teams" is "PACERS". */
        if (teamName.equals("PACERS")) {
            
            /* Changes the text of the Hint Label to some piece of information 
            related to the "PACERS" to aid the user in guessing the team. */
            labelHint.setText("This team is based in Indianapolis, Indiana, USA.");
        }
        
/*************Only to indicate separation between hints of 2 teams*************/

        /* This command checks if the randomly generated team name from the 
        String Array "teams" is "CELTICS". */
        if (teamName.equals("CELTICS")) {
            
            /* Changes the text of the Hint Label to some piece of information 
            related to the "CELTICS" to aid the user in guessing the team. */
            labelHint.setText("This team has won the most championships in the NBA with 17.");
        }
        
/*************Only to indicate separation between hints of 2 teams*************/
        
        /* This command checks if the randomly generated team name from the 
        String Array "teams" is "ROCKETS". */
        if (teamName.equals("ROCKETS")) {
            
            /* Changes the text of the Hint Label to some piece of information 
            related to the "ROCKETS" to aid the user in guessing the team. */
            labelHint.setText("This team drafted Hakeem Olajuwon, possibly the greatest defender of all time.");
        }
        
/*************Only to indicate separation between hints of 2 teams*************/
        
        /* This command checks if the randomly generated team name from the 
        String Array "teams" is "CLIPPERS". */
        if (teamName.equals("CLIPPERS")) {
            
            /* Changes the text of the Hint Label to some piece of information 
            related to the "CLIPPERS" to aid the user in guessing the team. */
            labelHint.setText("This team shares its home arena (Staples Center) with the Los Angeles Lakers.");
        }
        
/*************Only to indicate separation between hints of 2 teams*************/

        /* This command checks if the randomly generated team name from the 
        String Array "teams" is "BUCKS". */
        if (teamName.equals("BUCKS")) {
            
            /* Changes the text of the Hint Label to some piece of information 
            related to the "BUCKS" to aid the user in guessing the team. */
            labelHint.setText("This team is based in Milwaukee, Wisconsin, USA.");
        }
        
/*************Only to indicate separation between hints of 2 teams*************/
        
        /* This command checks if the randomly generated team name from the 
        String Array "teams" is "BULLS". */
        if (teamName.equals("BULLS")) {
            
            /* Changes the text of the Hint Label to some piece of information 
            related to the "BULLS" to aid the user in guessing the team. */
            labelHint.setText("Michael Jordan led this team to 3 consecutive NBA championships (twice).");
        }
        
/*************Only to indicate separation between hints of 2 teams*************/

        /* This command checks if the randomly generated team name from the 
        String Array "teams" is "PELICANS". */
        if (teamName.equals("PELICANS")) {
            
            /* Changes the text of the Hint Label to some piece of information 
            related to the "PELICANS" to aid the user in guessing the team. */
            labelHint.setText("This team is based in New Orleans, Louisiana, USA.");
        }
        
/*************Only to indicate separation between hints of 2 teams*************/

        /* This command checks if the randomly generated team name from the 
        String Array "teams" is "SPURS". */
        if (teamName.equals("SPURS")) {
            
            /* Changes the text of the Hint Label to some piece of information 
            related to the "SPURS" to aid the user in guessing the team. */
            labelHint.setText("This team has not missed the playoffs since 1998 (longest streak of consecutive Playoff Appearances).");
        }
        
/*************Only to indicate separation between hints of 2 teams*************/

        /* This command checks if the randomly generated team name from the 
        String Array "teams" is "KNICKS". */
        if (teamName.equals("KNICKS")) {
            
            /* Changes the text of the Hint Label to some piece of information 
            related to the "KNICKS" to aid the user in guessing the team. */
            labelHint.setText("This team is the most valuable team in the NBA at $4.6 billion (2020).");
        }
        
/*************Only to indicate separation between hints of 2 teams*************/

        /* This command checks if the randomly generated team name from the 
        String Array "teams" is "CAVALIERS". */
        if (teamName.equals("CAVALIERS")) {
            
            /* Changes the text of the Hint Label to some piece of information 
            related to the "CAVALIERS" to aid the user in guessing the team. */
            labelHint.setText("This is the only team in NBA history to come back from a 3-1 deficit to win the NBA Finals.");
        }
        
/*************Only to indicate separation between hints of 2 teams*************/

        /* This command checks if the randomly generated team name from the 
        String Array "teams" is "JAZZ". */
        if (teamName.equals("JAZZ")) {
            
            /* Changes the text of the Hint Label to some piece of information 
            related to the "JAZZ" to aid the user in guessing the team. */
            labelHint.setText("This team is based in Salt Lake City, Utah, USA.");
        }
        
/*************Only to indicate separation between hints of 2 teams*************/

        /* This command checks if the randomly generated team name from the 
        String Array "teams" is "THUNDER". */
        if (teamName.equals("THUNDER")) {
            
            /* Changes the text of the Hint Label to some piece of information 
            related to the "THUNDER" to aid the user in guessing the team. */
            labelHint.setText("This team is based in Oklahoma City, Oklahoma, USA.");
        }
        
/*************Only to indicate separation between hints of 2 teams*************/

        /* This command checks if the randomly generated team name from the 
        String Array "teams" is "NETS". */
        if (teamName.equals("NETS")) {
            
            /* Changes the text of the Hint Label to some piece of information 
            related to the "NETS" to aid the user in guessing the team. */
            labelHint.setText("This team is based in Brooklyn, New York, USA.");
        }
        
/*************Only to indicate separation between hints of 2 teams*************/

        /* This command checks if the randomly generated team name from the 
        String Array "teams" is "TRAILBLAZERS". */
        if (teamName.equals("TRAILBLAZERS")) {
            
            /* Changes the text of the Hint Label to some piece of information 
            related to the "TRAILBLAZERS" to aid the user in guessing the team. */
            labelHint.setText("This team is based in Portland, Oregon, USA.");
        }
        
/*************Only to indicate separation between hints of 2 teams*************/

        /* This command checks if the randomly generated team name from the 
        String Array "teams" is "NUGGETS". */
        if (teamName.equals("NUGGETS")) {
            
            /* Changes the text of the Hint Label to some piece of information 
            related to the "NUGGETS" to aid the user in guessing the team. */
            labelHint.setText("This team is based in the Mile High City");
        }
        
/*************Only to indicate separation between hints of 2 teams*************/

        /* This command checks if the randomly generated team name from the 
        String Array "teams" is "GRIZZLIES". */
        if (teamName.equals("GRIZZLIES")) {
            
            /* Changes the text of the Hint Label to some piece of information 
            related to the "GRIZZLIES" to aid the user in guessing the team. */
            labelHint.setText("This team is based in Memphis, Tennessee, USA.");
        }
        
/*************Only to indicate separation between hints of 2 teams*************/

        /* This command checks if the randomly generated team name from the 
        String Array "teams" is "HORNETS". */
        if (teamName.equals("HORNETS")) {
            
            /* Changes the text of the Hint Label to some piece of information 
            related to the "HORNETS" to aid the user in guessing the team. */
            labelHint.setText("This team is owned by retired NBA player, Michael Jordan.");
        }
        
/*************Only to indicate separation between hints of 2 teams*************/

        /* This command checks if the randomly generated team name from the 
        String Array "teams" is "MAGIC". */
        if (teamName.equals("MAGIC")) {
            
            /* Changes the text of the Hint Label to some piece of information 
            related to the "MAGIC" to aid the user in guessing the team. */
            labelHint.setText("This team is based in Orlando, Florida, USA.");
        }
        
/*************Only to indicate separation between hints of 2 teams*************/

        /* This command checks if the randomly generated team name from the 
        String Array "teams" is "WIZARDS". */
        if (teamName.equals("WIZARDS")) {
            
            /* Changes the text of the Hint Label to some piece of information 
            related to the "WIZARDS" to aid the user in guessing the team. */
            labelHint.setText("This team plays its home games in the Capital of the United States of America.");
        }
        
/*************Only to indicate separation between hints of 2 teams*************/

        /* This command checks if the randomly generated team name from the 
        String Array "teams" is "PISTONS". */
        if (teamName.equals("PISTONS")) {
            
            /* Changes the text of the Hint Label to some piece of information 
            related to the "PISTONS" to aid the user in guessing the team. */
            labelHint.setText("This team is based in Detroit, Michigan, USA.");
        }

        /* The Hint button is used to provide the user with some aid in guessing
        the team name. However, they only get 1 Hint per game so this command 
        disables the Hint Button, once clicked. */
        btnHint.setEnabled(false); 
    }//GEN-LAST:event_btnHintActionPerformed

    // Code for Resetting Score - Executed when user clicks "Clear Score".
    private void btnResetScoreActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnResetScoreActionPerformed

        /* Creates the pop-up which informs the user that the if they continue 
        with the "Clear XML File" option, the game screen will also reset, 
        resulting in the team name they must guess also changing. */
        int clear = JOptionPane.showConfirmDialog(this, "Are you sure you want "
                + "to clear the game scores? \n This will also change the "
                + "team name you must guess.", "Confirm", JOptionPane.YES_NO_OPTION);
        
        /* This command checks if the user has clicked the "YES" button on tbe 
        Pop-up window. If this is the case, the method "clearXML()" defined 
        above is called.*/
        if (clear == JOptionPane.YES_OPTION) {
            
            // This command calls the method, "clearXML()" defined above.
            clearXML();
            
            JavaGameScreen object1 = new JavaGameScreen();
        
            /* After the user has clicked the "Yes" button on the Pop-up window,
            it means they wish to clear the XML file. Due to this, the game 
            screen must be closed and reopened to also change the text on the 
            3 JLabels, keeping track of the number of games played/won/lost. 
            Therefore, the "this.setVisible(false)" command closes the current, 
            "JavaGameScreen" JFrame. */
            this.setVisible(false);

            // Opens the "JavaGameScreen" Frame which was defined is "object1" above
            object1.setVisible(true);    
        } 
    }//GEN-LAST:event_btnResetScoreActionPerformed

    // Command Line Arguement that executes the entire program.
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(JavaGameScreen.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(JavaGameScreen.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(JavaGameScreen.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(JavaGameScreen.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new JavaGameScreen().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton btnA;
    private javax.swing.JButton btnB;
    private javax.swing.JButton btnC;
    private javax.swing.JButton btnD;
    private javax.swing.JButton btnE;
    private javax.swing.JButton btnF;
    private javax.swing.JButton btnG;
    private javax.swing.JButton btnH;
    private javax.swing.JButton btnHint;
    private javax.swing.JButton btnI;
    private javax.swing.JButton btnJ;
    private javax.swing.JButton btnK;
    private javax.swing.JButton btnL;
    private javax.swing.JButton btnM;
    private javax.swing.JButton btnN;
    private javax.swing.JButton btnO;
    private javax.swing.JButton btnP;
    private javax.swing.JButton btnQ;
    private javax.swing.JButton btnR;
    private javax.swing.JButton btnResetScore;
    private javax.swing.JButton btnS;
    private javax.swing.JButton btnT;
    private javax.swing.JButton btnU;
    private javax.swing.JButton btnV;
    private javax.swing.JButton btnW;
    private javax.swing.JButton btnX;
    private javax.swing.JButton btnY;
    private javax.swing.JButton btnZ;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel labelGamesPlayed;
    private javax.swing.JLabel labelHangmanImage;
    private javax.swing.JLabel labelHead;
    private javax.swing.JLabel labelHint;
    private javax.swing.JLabel labelLosses;
    private javax.swing.JLabel labelUnderlineName;
    private javax.swing.JLabel labelWins;
    private javax.swing.JPanel panelButtons;
    // End of variables declaration//GEN-END:variables
}