/******************************************************************************
* File Name:	FinalGame_Hangman
* Programmer:	Arnav Gupta
* Date:		March 22, 2020
* Description:	This program is designed to simulate the game of Hangman. It 
*               will include the user having to guess the names of the 30 teams 
*               in the NBA (National Basketball Association). The user will 
*               guess from the 26 letters in the alphabet. If the letter guessed
*               by the user is in the name, its position will be revealed. The 
*               user can only have a maximum of 6 incorrect guesses. After that,
*               the game will be over and the user will have the option to 
*               either Play Again or Exit.
*******************************************************************************/

// Imports the libraries required for the execution of the code.
import java.io.File;
import javax.swing.JOptionPane;
import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.parsers.ParserConfigurationException;
import javax.xml.transform.OutputKeys;
import javax.xml.transform.Transformer;
import javax.xml.transform.TransformerException;
import javax.xml.transform.TransformerFactory;
import javax.xml.transform.dom.DOMSource;
import javax.xml.transform.stream.StreamResult;
import org.w3c.dom.Document;
import org.w3c.dom.Element;

// "JavaWelcomeScreen" class with "javax.swing.JFrame" extension
public class JavaWelcomeScreen extends javax.swing.JFrame {

    // Creates the Output Window
    public JavaWelcomeScreen() {
        
        /* The JFrame has been centered on the Screen by clicking the 
        "Generate Center" under the Properties Section of the JFrame. */
        initComponents();
        
        /* This command calls the method, "clearXML()" defined below. The XML 
        file stores the Game Scores even after the user exits the game. But, 
        once they restart the game, the XML file is cleared. */
        clearXML();
    }
    
    /* Defines a new method, "clearXML()", which will be used to clear the XML 
    file should the user choose to do so. */
    public static void clearXML() {
        
        // This trys to catch any exceptions in the code
        try {  
            
            // This allows for the creation of the XML file
            DocumentBuilderFactory docFactory = DocumentBuilderFactory.newInstance();   
            
            // Enables information to read from XML file 
            DocumentBuilder docBuilder = docFactory.newDocumentBuilder();  
            
            // Root elements
            Document doc = docBuilder.newDocument();
            
            // Calls the root element in the XML "HangmanScore"
            Element rootElement = doc.createElement("HangmanScore");  
            doc.appendChild(rootElement);
            
            // Score elements
            Element games = doc.createElement("Games");
            rootElement.appendChild(games);
            
            // Number of games played element and appends a String value of "0".         
            Element played = doc.createElement("Played");
            played.appendChild(doc.createTextNode("0"));
            games.appendChild(played);
            
            // Number of games won element and appends a String value of "0".
            Element won = doc.createElement("Won");
            won.appendChild(doc.createTextNode("0"));
            games.appendChild(won);
            
            // Number of games lost element and appends a String value of "0".
            Element lost = doc.createElement("Lost");
            lost.appendChild(doc.createTextNode("0"));
            games.appendChild(lost);
     
            // write the content into XML file
            TransformerFactory transformerFactory = TransformerFactory.newInstance();
            Transformer transformer = transformerFactory.newTransformer();
            DOMSource source = new DOMSource(doc);

            // Makes sure the XML file is formatted nicely with indentation
            transformer.setOutputProperty(OutputKeys.INDENT, "yes");   

            // Makes sure the XML file is formatted nicely with indent space of 4 
            transformer.setOutputProperty("{http://xml.apache.org/xslt}indent-amount", "4");  

            // creates the file called "Score"
            StreamResult result = new StreamResult(new File("Score.xml"));  

            // Output to console screen  for testing, but you need to comment-out the previous "StreamResult result" line above. 
            //StreamResult result = new StreamResult(System.out);
            transformer.transform(source, result); 
        }
        
        // Tries to catch any exceptions
        catch (ParserConfigurationException | TransformerException pce) { 
            pce.printStackTrace();
	} 
    }

    /**
     * This method is called from within the constructor to initialize the form.
     * WARNING: Do NOT modify this code. The content of this method is always
     * regenerated by the Form Editor.
     */
    @SuppressWarnings("unchecked")
    
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        labelTitle = new javax.swing.JLabel();
        labelProgrammer = new javax.swing.JLabel();
        btnPlayGame = new javax.swing.JButton();
        btnInstructions = new javax.swing.JButton();
        btnExit = new javax.swing.JButton();
        labelImage = new javax.swing.JLabel();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        setTitle("Hangman");
        setPreferredSize(new java.awt.Dimension(800, 800));

        labelTitle.setFont(new java.awt.Font("Tahoma", 1, 90)); // NOI18N
        labelTitle.setText("HANGMAN");
        labelTitle.setToolTipText("");

        labelProgrammer.setFont(new java.awt.Font("Tahoma", 1, 36)); // NOI18N
        labelProgrammer.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        labelProgrammer.setText("By: Arnav Gupta");
        labelProgrammer.setPreferredSize(new java.awt.Dimension(395, 58));

        btnPlayGame.setBackground(new java.awt.Color(255, 153, 0));
        btnPlayGame.setFont(new java.awt.Font("Verdana", 1, 24)); // NOI18N
        btnPlayGame.setText("Play Game");
        btnPlayGame.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnPlayGameActionPerformed(evt);
            }
        });

        btnInstructions.setBackground(new java.awt.Color(0, 153, 0));
        btnInstructions.setFont(new java.awt.Font("Verdana", 1, 24)); // NOI18N
        btnInstructions.setText("Instructions");
        btnInstructions.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnInstructionsActionPerformed(evt);
            }
        });

        btnExit.setBackground(new java.awt.Color(255, 0, 0));
        btnExit.setFont(new java.awt.Font("Verdana", 1, 24)); // NOI18N
        btnExit.setText("Exit");
        btnExit.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnExitActionPerformed(evt);
            }
        });

        labelImage.setIcon(new javax.swing.ImageIcon("C:\\Users\\arnav\\Desktop\\FinalGame\\Photos\\Intro.png")); // NOI18N

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(layout.createSequentialGroup()
                        .addGap(50, 50, 50)
                        .addComponent(btnPlayGame, javax.swing.GroupLayout.PREFERRED_SIZE, 200, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(50, 50, 50)
                        .addComponent(btnInstructions, javax.swing.GroupLayout.PREFERRED_SIZE, 200, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(50, 50, 50)
                        .addComponent(btnExit, javax.swing.GroupLayout.PREFERRED_SIZE, 200, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGroup(layout.createSequentialGroup()
                        .addGap(74, 74, 74)
                        .addComponent(labelImage))
                    .addGroup(layout.createSequentialGroup()
                        .addGap(161, 161, 161)
                        .addComponent(labelTitle, javax.swing.GroupLayout.PREFERRED_SIZE, 478, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGroup(layout.createSequentialGroup()
                        .addGap(250, 250, 250)
                        .addComponent(labelProgrammer, javax.swing.GroupLayout.PREFERRED_SIZE, 300, javax.swing.GroupLayout.PREFERRED_SIZE)))
                .addContainerGap(50, Short.MAX_VALUE))
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addGap(20, 20, 20)
                .addComponent(labelImage)
                .addGap(20, 20, 20)
                .addComponent(labelTitle, javax.swing.GroupLayout.PREFERRED_SIZE, 110, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(20, 20, 20)
                .addComponent(labelProgrammer, javax.swing.GroupLayout.PREFERRED_SIZE, 50, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(30, 30, 30)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(btnPlayGame, javax.swing.GroupLayout.PREFERRED_SIZE, 75, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(btnInstructions, javax.swing.GroupLayout.PREFERRED_SIZE, 75, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(btnExit, javax.swing.GroupLayout.PREFERRED_SIZE, 75, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addContainerGap(76, Short.MAX_VALUE))
        );

        pack();
        setLocationRelativeTo(null);
    }// </editor-fold>//GEN-END:initComponents

    // Code for Play Game Button - Executed when user clicks "Play Game".
    private void btnPlayGameActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnPlayGameActionPerformed
        
        JavaGameScreen object1 = new JavaGameScreen();
        
        /* After the user has clicked the "Play Game" button, it means they 
        wish to continue with the game, Therefore, the "this.setVisible(false)" 
        command closes the current, "JavaWelcomeScreen" JFrame. */
        this.setVisible(false);
        
        // Opens the "JavaGameScreen" Frame which was defined is "object1" above
        object1.setVisible(true);
    }//GEN-LAST:event_btnPlayGameActionPerformed

    // Code for Information Button - Executed when user clicks "Information".  
    private void btnInstructionsActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnInstructionsActionPerformed
        
        // Will create pop-up and display the exit message.
        JOptionPane instructions = new JOptionPane ("Information");
        JOptionPane.showMessageDialog(null, "Instructions: \n************** \n\n" 
            + "1)  This program simulates the game of Hangman. This edition \n" 
            + "      is modified to include the names of 29 teams in the \n" 
            + "      NBA excluding the PHILADELPHIA 76ERS. \n" 
            + "                                       *************************** \n\n"
                
            + "2)  In this game, you must try to guess a team name which is \n " 
            + "     randomly generated, by choosing letters of the alphabet. \n\n"

            + "3)  As you guess the letters correctly, the position of the \n " 
            + "     letter in the team name will be disclosed. Once all of \n" 
            + "      the letters of the hidden word are uncovered, you will have won! \n\n"

            + "4)  There is maximum of 6 incorrect guesses. Everytime you guess \n" 
            + "     an incorrect letter, a body part is added to the “Hangman” image. \n\n"
                
            + "5)  For this game, there is also an option to get a HINT as to \n"
            + "      what the team name is. However, you only get 1 Hint per \n" 
            + "      round so USE IT CAREFULLY. \n\n"
                
            + "6)  Once the FULL BODY appears, the game ENDS and you will have \n" 
            + "      the option to either Play Again or Quit.");
    }//GEN-LAST:event_btnInstructionsActionPerformed

    // Code for Exit Button - Executed when user clicks "Exit".
    private void btnExitActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnExitActionPerformed

        // Will create pop-up and display the exit message.
        JOptionPane goodbye = new JOptionPane ("Goodbye");
        JOptionPane.showMessageDialog(null, "We're sorry to see you go. Enjoy "
                + "the rest of your day, Goodbye.");
           
        // Exits the program.
        System.exit(0);
    }//GEN-LAST:event_btnExitActionPerformed

    // Command Line Arguement that executes the entire program.
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(JavaWelcomeScreen.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(JavaWelcomeScreen.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(JavaWelcomeScreen.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(JavaWelcomeScreen.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new JavaWelcomeScreen().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton btnExit;
    private javax.swing.JButton btnInstructions;
    private javax.swing.JButton btnPlayGame;
    private javax.swing.JLabel labelImage;
    private javax.swing.JLabel labelProgrammer;
    private javax.swing.JLabel labelTitle;
    // End of variables declaration//GEN-END:variables
}